//============================================================
// INT0_INT1_Debounce_Events.ino
//
// This sketch will configure an INT0 interrupt for a falling
// interrupt stimulus on pin D2, where we have a pushbutton
// switch. The interrupt will never be enabled, only 
// configured. The ATmega328P on board will read the state of
// the pin and if it goes LOW, will set the interrupt flag, 
// but will not trigger any interrupt handlers---we have not
// created one anyway.
//
// Pressing the switch many times, or having it bounce as they
// usually do, will not be a problem---the code will see only
// one press regardless.
//
// The switch will be used to toggle an LED, what else, on D8.
//
// There's the usual built in LED on D13, and this will be 
// toggled every 2 seconds to simulate real work. The code 
// will show that the switch will be recognised and acted upon
// even if it is pressed during the delay(). (Or while the
// code is actually doing some useful work.)
//
// Norman Dunbar.
// 9 October 2026.
//============================================================

//--------------------------------------------------------
// The EIFR bit we care about, plus LEDs and switches.
//--------------------------------------------------------
const uint8_t INT_FLAG = (1 << INT0);
const uint8_t LED_1 = 8;
const uint8_t LED_2 = LED_BUILTIN;
const uint8_t BUTTON = 2;




void setup() {
    //--------------------------------------------------------
    // Configure the switch on D2 and LEDs. It's not strictly
    // necessary to configure the switch, but we need pullups
    // enabled. We could use external resistors, of course, to
    // pull the switch on D2 up or down.
    //--------------------------------------------------------
    pinMode(LED_1, OUTPUT);
    pinMode(LED_2, OUTPUT);
    pinMode(BUTTON, INPUT_PULLUP);

    //--------------------------------------------------------
    // Configure an INT0 interrupt on D2. We don't enable the
    // interrupt though as we will use a scan to check if the
    // switch on D2 was pressed "at some point". If so, we 
    // will toggle the LED on D8.
    // 
    // The EICRA.ISC01 and EICRA.ISC00 bit settings are:
    //
    // 00 = LOW (LEVEL, must be held low or nothing happens)
    // 01 = CHANGE
    // 10 = FALLING <--- We are using this one.
    // 11 = RISING
    //
    // As the switch is pulled up, we look for a
    // FALLING change on it.
    //--------------------------------------------------------
    // We have to talk directly to the registers here as there
    // is nothing in the Arduino Language that will do this
    // for us without enabling the INT0 interrupt. We only
    // want to *configure* the interrupt, not *enable* it.
    //--------------------------------------------------------
    EICRA = (1 << ISC01) | (0 << ISC00);      /* INT0 */
}



void loop() {

    //--------------------------------------------------------
    // See if an "interrupt" occurred on D2 or D3. Pressing
    // the switch should change the EIFR.INT0 bit. The flag
    // bit will need to be manually cleared by the code as we
    // are not triggering the INT0 interrupt.
    //
    // Once again, we need to talk directly to the registers.
    //--------------------------------------------------------
    if (EIFR & INT_FLAG) {
        // Clear the INT0 interrupt flag.
        EIFR |= INT_FLAG;

        // Toggle D8 when the button press is noticed.
        digitalWrite(LED_1, !digitalRead(LED_1));
    }

    //--------------------------------------------------------
    // At this point, the code should be off doing a bit of
    // useful work, only checking the switch every so often.
    // We could insert a delay here to simulate the work done,
    // I tested with delays from 10 up tp 5000 and it "just"
    // works. In actual fact, no delay is necessary, but if
    // you have one of a decent length, you will note that the
    // switch does respond correctly, even if a delay is
    // noticed.
    //--------------------------------------------------------
    // NOTE: The switch will respond with a press once and
    // once only no matter how often the user hammers it, or 
    // no matter how bouncy the switch is. As soon as it goes
    // low when pressed, the EIFR.INT0 bit is set to indicate
    // a press. This bit is what we look for instead of always
    // reading the switch when we want to know if it was 
    // pressed.
    //--------------------------------------------------------
    // To simulate "real" work, we toggle the built in LED
    // once every second, and yes, we are using a delay! In
    // normal circumstances, the user would have to press the 
    // button in the time between the final delay() ending and 
    // the next one beginning otherwise the press would be
    // missed. With this setup, the press doesn't go missing
    // and the D8 LED will toggle when the built in LED next
    // toggles, assuming the button has indeed been pressed.
    //--------------------------------------------------------
    digitalWrite(LED_2, !digitalRead(LED_2));


   //--------------------------------------------------------
   // This delay(), as well as determining when the built in
   // LED will toggle, also determines when the button press
   // will be acted upon.
   //
   // It should be noted that such a setup is NOT SUITABLE if
   // the code is monitoring a safety cutout switch, for that
   // you defintely need an interrupt and handler.
   //--------------------------------------------------------
    delay(1000);
}
